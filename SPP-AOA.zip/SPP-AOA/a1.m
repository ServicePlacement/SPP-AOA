function a1(q)
global asicoda;
asicoda=asicoda/2;
end
