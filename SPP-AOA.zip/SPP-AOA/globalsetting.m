global ProblemSetting;
ProblemSetting.CostFunction=CostFunction;
ProblemSetting.npar=npar;
ProblemSetting.VarMin=VarMin;
ProblemSetting.VarMax=VarMax;

global CuckooSetting;
CuckooSetting.NumCuckoos=NumCuckoos;
CuckooSetting.MinNumberOfEggs=MinNumberOfEggs;
CuckooSetting.MaxNumberOfEggs=MaxNumberOfEggs;
CuckooSetting.NumberOfCluster=NumberOfCluster;
CuckooSetting.MaxNumOfCuckoo=MaxNumOfCuckoo;
CuckooSetting.RadiusCoeff=RadiusCoeff;
CuckooSetting.MotionCoeff=MotionCoeff;
CuckooSetting.MaxIter=MaxIter;
